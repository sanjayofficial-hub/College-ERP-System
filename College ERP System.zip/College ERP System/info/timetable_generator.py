"""
Timetable Generator Module for College ERP System
This module contains algorithms to automatically generate timetables based on teachers and subjects.
"""

import random
from collections import defaultdict
from .models import Assign, AssignTime, time_slots, DAYS_OF_WEEK, Class, Course, Teacher


class TimetableGenerator:
    """Class to generate timetables automatically based on teacher and subject constraints."""
    
    def __init__(self):
        self.assignments = []
        self.class_timetables = {}
        self.teacher_timetables = {}
        self.time_slots = [slot[0] for slot in time_slots]
        self.days = [day[0] for day in DAYS_OF_WEEK]
        self.class_subjects = defaultdict(list)
        self.teacher_workload = defaultdict(int)
        
    def load_data(self):
        """Load required data from the database."""
        self.assignments = list(Assign.objects.all())
        
        # Group subjects by class
        for assignment in self.assignments:
            self.class_subjects[assignment.class_id.id].append(assignment)
            self.teacher_workload[assignment.teacher.id] += 1
            
        # Initialize empty timetables
        for class_id in self.class_subjects.keys():
            self.class_timetables[class_id] = {}
            for day in self.days:
                self.class_timetables[class_id][day] = {}
                for slot in self.time_slots:
                    self.class_timetables[class_id][day][slot] = None
        
        # Initialize teacher timetables
        for assignment in self.assignments:
            teacher_id = assignment.teacher.id
            if teacher_id not in self.teacher_timetables:
                self.teacher_timetables[teacher_id] = {}
                for day in self.days:
                    self.teacher_timetables[teacher_id][day] = {}
                    for slot in self.time_slots:
                        self.teacher_timetables[teacher_id][day][slot] = None
    
    def is_teacher_available(self, teacher_id, day, slot):
        """Check if teacher is available for the given day and time slot."""
        return self.teacher_timetables.get(teacher_id, {}).get(day, {}).get(slot) is None
    
    def is_class_available(self, class_id, day, slot):
        """Check if class is available for the given day and time slot."""
        return self.class_timetables.get(class_id, {}).get(day, {}).get(slot) is None
    
    def allocate_slot(self, assignment, day, slot):
        """Allocate a time slot for an assignment."""
        class_id = assignment.class_id.id
        teacher_id = assignment.teacher.id
        
        self.class_timetables[class_id][day][slot] = assignment
        self.teacher_timetables[teacher_id][day][slot] = assignment
        
        # Save the assignment time to the database
        assign_time = AssignTime(
            assign=assignment,
            day=day,
            period=slot
        )
        return assign_time
    
    def generate_timetable(self):
        """Generate a complete timetable for all classes."""
        self.load_data()
        
        # Clear existing timetable data
        AssignTime.objects.all().delete()
        
        assign_times = []
        
        # Sort assignments by teacher workload (teachers with more subjects get priority)
        sorted_assignments = sorted(
            self.assignments, 
            key=lambda x: self.teacher_workload[x.teacher.id], 
            reverse=True
        )
        
        # Define which slots are actual teaching periods (not breaks)
        teaching_slots = [0, 1, 3, 4, 6, 7]  # Indices of time_slots that are not breaks
        
        # First, ensure each day has at least one assignment for each class
        class_day_coverage = {class_id: set() for class_id in self.class_subjects.keys()}
        days_per_class = 5  # Try to have classes on 5 different days
        
        # Distribute assignments evenly across days first
        for assignment in sorted_assignments:
            class_id = assignment.class_id.id
            
            # Try to place this assignment on days where this class doesn't have assignments yet
            if len(class_day_coverage[class_id]) < days_per_class:
                for day in self.days:
                    # Skip if this class already has an assignment on this day
                    if day in class_day_coverage[class_id]:
                        continue
                        
                    # Try each slot
                    for slot_idx in teaching_slots:
                        slot = self.time_slots[slot_idx]
                        if (self.is_teacher_available(assignment.teacher.id, day, slot) and 
                            self.is_class_available(assignment.class_id.id, day, slot)):
                            # Allocate this slot
                            assign_time = self.allocate_slot(assignment, day, slot)
                            assign_times.append(assign_time)
                            class_day_coverage[class_id].add(day)
                            break
                            
                    # If we added an assignment for this day, move to next day
                    if day in class_day_coverage[class_id]:
                        break
        
        # Now distribute the remaining assignments to fill up empty slots
        for assignment in sorted_assignments:
            class_id = assignment.class_id.id
            
            # Count how many times this assignment has been allocated
            allocated_count = sum(1 for at in assign_times if at.assign == assignment)
            
            # Skip if it's already been allocated at least 3 times
            if allocated_count >= 3:
                continue
                
            # Try to fill remaining slots
            slots_to_allocate = 3 - allocated_count
            
            if slots_to_allocate <= 0:
                continue
                
            # Find all available slots
            possible_slots = []
            for day in self.days:
                for slot_idx in teaching_slots:
                    slot = self.time_slots[slot_idx]
                    if (self.is_teacher_available(assignment.teacher.id, day, slot) and 
                        self.is_class_available(assignment.class_id.id, day, slot)):
                        possible_slots.append((day, slot))
            
            # Shuffle to avoid patterned allocations
            random.shuffle(possible_slots)
            
            # Allocate as many as needed (or as many as possible)
            for i in range(min(slots_to_allocate, len(possible_slots))):
                day, slot = possible_slots[i]
                assign_time = self.allocate_slot(assignment, day, slot)
                assign_times.append(assign_time)
        
        # Final pass: Try to fill any remaining empty slots
        for class_id in self.class_subjects.keys():
            assignments_for_class = [a for a in sorted_assignments if a.class_id.id == class_id]
            
            # Go through each day and slot
            for day in self.days:
                for slot_idx in teaching_slots:
                    slot = self.time_slots[slot_idx]
                    # Skip if this slot is already filled
                    if not self.is_class_available(class_id, day, slot):
                        continue
                    
                    # Try to fill with any available assignment
                    for assignment in assignments_for_class:
                        if self.is_teacher_available(assignment.teacher.id, day, slot):
                            assign_time = self.allocate_slot(assignment, day, slot)
                            assign_times.append(assign_time)
                            break
        
        # Save all assign times at once for better performance
        AssignTime.objects.bulk_create(assign_times)
        
        return {
            'class_timetables': self.class_timetables,
            'teacher_timetables': self.teacher_timetables,
            'slots_allocated': len(assign_times)
        }
    
    def optimize_timetable(self):
        """Optimize the generated timetable by minimizing gaps."""
        # Add optimization logic here if needed
        pass
    
    def get_clashes(self):
        """Identify any clashes in the timetable."""
        clashes = []
        
        # Check for teacher being allocated in multiple classes at the same time
        for day in self.days:
            for slot in self.time_slots:
                teacher_allocations = defaultdict(list)
                
                for class_id, timetable in self.class_timetables.items():
                    assignment = timetable.get(day, {}).get(slot)
                    if assignment:
                        teacher_id = assignment.teacher.id
                        teacher_allocations[teacher_id].append((class_id, assignment))
                
                for teacher_id, allocations in teacher_allocations.items():
                    if len(allocations) > 1:
                        clashes.append({
                            'day': day,
                            'slot': slot,
                            'teacher_id': teacher_id,
                            'teacher_name': Teacher.objects.get(id=teacher_id).name,
                            'allocations': allocations
                        })
        
        return clashes


def generate_timetable():
    """Helper function to generate timetable."""
    generator = TimetableGenerator()
    return generator.generate_timetable()


def get_timetable_for_class(class_id):
    """Get generated timetable for a specific class."""
    assign_times = AssignTime.objects.filter(assign__class_id=class_id).select_related('assign')
    
    timetable = {}
    for day in [d[0] for d in DAYS_OF_WEEK]:
        timetable[day] = {}
        for slot in [s[0] for s in time_slots]:
            timetable[day][slot] = None
    
    for assign_time in assign_times:
        day = assign_time.day
        slot = assign_time.period
        timetable[day][slot] = assign_time.assign
    
    return timetable 